package com.example.nit.Models

import java.io.Serializable

class MovieDataModel(val id:Int, val name:String, val description:String, val rate:Int):Serializable {
}